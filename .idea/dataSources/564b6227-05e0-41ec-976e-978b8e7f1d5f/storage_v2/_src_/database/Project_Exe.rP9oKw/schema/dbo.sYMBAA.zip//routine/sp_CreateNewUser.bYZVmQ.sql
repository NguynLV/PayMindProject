CREATE   PROCEDURE dbo.sp_CreateNewUser
    @Email NVARCHAR(255),
    @PasswordHash NVARCHAR(500),
    @FirstName NVARCHAR(100),
    @LastName NVARCHAR(100),
    @Currency NVARCHAR(10),
    @NewUserId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Users (Email, PasswordHash, FirstName, LastName, Currency, CreatedAt, IsActive)
    VALUES (@Email, @PasswordHash, @FirstName, @LastName, @Currency, GETDATE(), 1);

    SET @NewUserId = SCOPE_IDENTITY();
END;
go

